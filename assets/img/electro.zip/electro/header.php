<?php
/**
 * Header for our theme
 */

electro_get_header();